<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{paysafecash}prestashop>paysafecash_30bb072092f15a4b05b8a91c63fe2d9a'] = 'Paysafecash';
$_MODULE['<{paysafecash}prestashop>paysafecash_8e15cbfc33103df39416ac733391a58c'] = 'Το Paysafecash συνιστά μια μέθοδο πληρωμής μετρητών. Δημιούργησε έναν κωδικό QR ή Barcode και πλήρωσε σε ένα κατάστημα που βρίσκεται κοντά σου.  Στη σελίδα www.paysafecash.com θα βρεις περισσότερες πληροφορίες καθώς και τα παραρτήματα συνεργατών.';

$_MODULE['<{paysafecash}prestashop>confirmation_88526efe38fd18179a127024aba8c1d7'] = 'Η παραγγελία σας στο %s είναι πλήρης.';
$_MODULE['<{paysafecash}prestashop>confirmation_b2f40690858b404ed10e62bdf422c704'] = 'Ποσό';
$_MODULE['<{paysafecash}prestashop>confirmation_63d5049791d9d79d86e9a108b0a999ca'] = 'Αναφορά';
$_MODULE['<{paysafecash}prestashop>confirmation_19c419a8a4f1cd621853376a930a2e24'] = 'Ένα μήνυμα ηλεκτρονικού ταχυδρομείου έχει σταλεί με αυτές τις πληροφορίες.';
$_MODULE['<{paysafecash}prestashop>confirmation_ca7e41a658753c87973936d7ce2429a8'] = 'Αν έχετε ερωτήσεις, σχόλια ή ανησυχίες, επικοινωνήστε με την ';
$_MODULE['<{paysafecash}prestashop>confirmation_cd430c2eb4b87fb3b49320bd21af074e'] = 'ομάδα εμπειρογνωμόνων υποστήριξης πελατών μας.';
$_MODULE['<{paysafecash}prestashop>confirmation_7569ab9b5973795ce8c9fc870d38d8e1'] = 'Η παραγγελία σας στο %s δεν έγινε δεκτή.';
$_MODULE['<{paysafecash}prestashop>confirmation_caa4088f1d295cf8ce8e358eb975ab32'] = 'Παρακαλούμε, προσπαθήστε να παραγγείλετε ξανά.';
$_MODULE['<{paysafecash}prestashop>confirmation_a25c753ee3e4be15ec0daa5a40deb7b8'] = 'Παρουσιάστηκε σφάλμα.';

$_MODULE['<{paysafecash}prestashop>payment_options_8b2afc4da8a75fb2b33529983fd08070'] = 'Πληρώστε με την Paysafecash';
$_MODULE['<{paysafecash}prestashop>payment_options_f270330ff96da91dd9c1f398ae54e781'] = 'Το Paysafecash συνιστά μια μέθοδο πληρωμής μετρητών. Δημιούργησε έναν κωδικό QR ή Barcode και πλήρωσε σε ένα κατάστημα που βρίσκεται κοντά σου.  Στη σελίδα www.paysafecash.com θα βρεις περισσότερες πληροφορίες καθώς και τα παραρτήματα συνεργατών.';

$_MODULE['<{paysafecash}prestashop>paysafecash_info_88526efe38fd18179a127024aba8c1d7'] = 'Η παραγγελία σας στο %s είναι πλήρης.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_b2f40690858b404ed10e62bdf422c704'] = 'Ποσό';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_63d5049791d9d79d86e9a108b0a999ca'] = 'Αναφορά';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_19c419a8a4f1cd621853376a930a2e24'] = 'Ένα μήνυμα ηλεκτρονικού ταχυδρομείου έχει σταλεί με αυτές τις πληροφορίες.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_ca7e41a658753c87973936d7ce2429a8'] = 'Αν έχετε ερωτήσεις, σχόλια ή ανησυχίες, επικοινωνήστε με την ';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_cd430c2eb4b87fb3b49320bd21af074e'] = 'ομάδα εμπειρογνωμόνων υποστήριξης πελατών μας.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_7569ab9b5973795ce8c9fc870d38d8e1'] = 'Η παραγγελία σας στο %s δεν έγινε δεκτή.';
$_MODULE['<{paysafecash}prestashop>paysafecash_info_caa4088f1d295cf8ce8e358eb975ab32'] = 'Παρακαλούμε, προσπαθήστε να παραγγείλετε ξανά.';

